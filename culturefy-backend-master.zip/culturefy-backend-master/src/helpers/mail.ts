import sgMail from '@sendgrid/mail'
import Logger from '../core/Logger'
import { SMTP } from '../config/globals'

export interface IMessage {
  to: string,
  subject: string,
  text: string,
  html: string,
}

sgMail.setApiKey(SMTP.SENDGRID_API_KEY)

export const sendMail = (msg: IMessage) => {
  sgMail
    .send({
      from: SMTP.SENDGRID_SENDER,
      ...msg
    })
    .then((response) => {
      Logger.info(`email send to ${msg.to}`)
    })
    .catch((error) => {
      Logger.error(`email send field ${msg.to}`)
      Logger.error(error)
    })
}
