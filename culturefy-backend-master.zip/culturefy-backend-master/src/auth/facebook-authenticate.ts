import passport from "passport";
import { Strategy } from "passport-facebook";

passport.serializeUser((user, done) => done(null, user));
// @ts-ignore
passport.deserializeUser((user, done) => done(null, user));

passport.use(new Strategy({
  clientID: "611015742909469",
  clientSecret: "757**********************bed",
  callbackURL: "http://localhost:8000/auth/facebook/callback"
},
  function (accessToken, refreshToken, profile, done) {
    return done(null, profile);
  }
));
