import { model, Schema, Document } from 'mongoose';
import { DOCUMENT_NAME as USER_DOCUMENT_NAME } from "../../../database/model/User"

export const DOCUMENT_NAME = 'Survey';
export const COLLECTION_NAME = 'survey';

export default interface Survey extends Document {
  title: any;
  user: string;
}

const schema = new Schema(
  {
    title: {
      type: Schema.Types.Mixed,
      required: true,
    },
    user: {
      type: Schema.Types.ObjectId,
      ref: USER_DOCUMENT_NAME,
    }
  },
  {
    versionKey: false,
    timestamps: true
  }
)

export const surveyModel = model<Survey>(DOCUMENT_NAME, schema, COLLECTION_NAME)
