import Survey, { surveyModel } from './survey';
import { NoDataError } from '../../../core/ApiError';
import { Schema } from 'mongoose';

export default class SurveyRepo {

  public static find(user: Schema.Types.ObjectId): Promise<Survey[]> {
    return surveyModel
      .find({ isDeleted: false, user })
      .select("-isDeleted -updatedAt")
      .lean<Survey[]>()
      .exec();
  }

  public static async create(body: Survey): Promise<{ bucket: Survey }> {    
    const bucket = await surveyModel.create({ ...body } as Survey);
    return { bucket };
  }

  public static async delete(id: string): Promise<{ bucket: any }> {
    const bucket = await surveyModel.findByIdAndDelete(id);
    if (!bucket) throw new NoDataError();
    return { bucket };
  }

  public static async updateCate(id: string, body: Survey): Promise<{ bucket: any }> {
    const bucket = await surveyModel.findByIdAndUpdate(id, {...body}as Survey);
    if (!bucket) throw new NoDataError();
    return { bucket };
  }

}
