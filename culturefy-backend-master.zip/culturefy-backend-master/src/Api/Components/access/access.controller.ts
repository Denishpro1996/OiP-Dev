import { Response, Request, NextFunction } from "express"
import { Types } from 'mongoose';
import asyncHandler from "../../../helpers/async";
import UserRepo from '../../../database/repository/UserRepo';
import { BusinessService } from "../business/business.service";
import { BadRequestError, AuthFailureError } from '../../../core/ApiError';
import User from '../../../database/model/User';
import { SuccessResponse, SuccessMsgResponse, TokenRefreshResponse } from '../../../core/ApiResponse';
import _ from 'lodash';
import { createTokens, getAccessToken, validateTokenData } from '../../../utils/authUtils';
import KeystoreRepo from '../../../database/repository/KeystoreRepo';
import { comparePassword } from "../../../utils/password";
import JWT from '../../../core/JWT';
// import { validateTokenData, createTokens, getAccessToken } from '../../../utils/authUtils';
import { AccessService } from './access.service'
import Logger from '../../../core/Logger';

export class AccessController {

  readonly service: AccessService = new AccessService()
  readonly BusinessService = new BusinessService()

  signup = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {
      console.log(req.body);

      const user = await UserRepo.findByEmail(req.body.email);
      if (user) throw new BadRequestError('User already registered');

      const { tokens, user: createdUser } = await this.service.generate('SIGNUP', req.body as User)

      Logger.info("Login Success", { user: _.pick(createdUser, ['_id', 'name', 'role', 'email', 'telegram_id']) })
      new SuccessResponse('Signup Successful', {
        user: _.pick(createdUser, ['_id', 'name', 'email', 'role', 'profilePicUrl', 'stripe_customerId']),
        tokens,
      }).send(res);
    }
  )

  createUser = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {

      req.body.createdBy = req.user._id

      const { user } = await UserRepo.createUser(req.body, req.body.role)

      Logger.info("Instructor Create Success")
      new SuccessResponse('User Created Successful', {
        user,
      }).send(res);
    }
  )

  // signupWithTelegram = asyncHandler(
  //   async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {
  //     console.log("We are here", req);
  //     const userExist = await UserRepo.findByTelegram(req.query.id);
  //     console.log(req.query);
  //     console.log(userExist);

  //     let user, tokens;
  //     if (userExist) {
  //       const { tokens: createdTokens, user: createdUser } = await this.service.generate('SIGNIN', userExist as User)
  //       user = createdUser;
  //       tokens = createdTokens;
  //     } else {
  //       const body = {
  //         telegram_id: req.query.id,
  //         name: `${req.query.first_name} ${req.query.last_name}`,
  //         profilePicUrl: req.query.photo_url
  //       }
  //       const { tokens: createdTokens, user: createdUser } = await this.service.generate('SIGNUP', body as User)
  //       user = createdUser;
  //       tokens = createdTokens;
  //     }
  //     res.redirect(`https://kingscharts.io?accessToken=${tokens?.accessToken}`)
  //   }
  // )

  signupWithGoogle = async (accessToken: any, refreshToken: any, unknow: any, profile: any, done: any) => {

    const userExist = await UserRepo.findByGoogle(profile.id, profile.emails[0].value);
    let user, tokens;
    if (userExist) {
      const { tokens: createdTokens, user: createdUser } = await this.service.generate('SIGNIN', userExist as User)
      user = createdUser;
      tokens = createdTokens;
    } else {
      const body = {
        google_id: profile.id,
        name: `${profile.displayName}`,
        email: profile.emails[0].value
      }
      const { tokens: createdTokens, user: createdUser } = await this.service.generate('SIGNUP', body as User)
      user = createdUser;
      tokens = createdTokens;
    }
    Logger.info("Login Success", { user: _.pick(user, ['_id', 'name', 'role', 'email', 'telegram_id']) })
    return done(null, { user, tokens });
  }

  signin = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {

      const user = await UserRepo.findByEmail(req.body.email);
      console.log(user);

      if (!user) throw new BadRequestError('Invalid credentials');
      if (!user.password || !user.email) throw new BadRequestError('Credential not set');

      comparePassword(req.body.password, user.password)

      const { tokens } = await this.service.generate('SIGNIN', user as User)

      Logger.info("Login Success", { user: _.pick(user, ['_id', 'name', 'role', 'email', 'telegram_id']) })

      new SuccessResponse('Login Success', {
        user: _.pick(user, ['_id', 'name', 'role', 'email', 'telegram_id']),
        tokens: tokens,
      }).send(res);

    }
  )

  loginSuccess = asyncHandler(
    async (req: Request, res: Response, next: NextFunction): Promise<Response | void> => {
      if (req.user) {
        // @ts-ignore
        res.redirect(`https://kingscharts.io?accessToken=${req.user?.tokens?.accessToken}`)
      } else {
        new AuthFailureError('Login with google field!')
      }
    }
  )

  signout = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {
      await KeystoreRepo.remove(req.keystore._id);
      new SuccessMsgResponse('Logout success').send(res);
    }
  )

  verify = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {

      const tokens = await createTokens(req.user, { ip: "192.168.0.2" }, req.keystore.primaryKey, req.keystore.secondaryKey)
      delete req.user.password
      new SuccessResponse('verify success', {
        user: req.user, // : _.pick(req.user, ['_id', 'name', 'role', 'email', 'telegram_id', 'profilePicUrl'])
        tokens
      }).send(res);
    }
  )

  createdByExist = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {

      const users = await UserRepo.findByCreatedBy(req.user._id)
      delete req.user.password
      new SuccessResponse('fetch success', {
        user: users, // : _.pick(req.user, ['_id', 'name', 'role', 'email', 'telegram_id', 'profilePicUrl'])
      }).send(res);
    }
  )

  refresh = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {
      req.accessToken = getAccessToken(req.headers.authorization); // Express headers are auto converted to lowercase

      const accessTokenPayload = await JWT.decode(req.accessToken);
      validateTokenData(accessTokenPayload);

      const user = await UserRepo.findById(new Types.ObjectId(accessTokenPayload.sub));
      if (!user) throw new AuthFailureError('User not registered');
      req.user = user;

      const refreshTokenPayload = await JWT.validate(req.body.refreshToken);
      validateTokenData(refreshTokenPayload);

      if (accessTokenPayload.sub !== refreshTokenPayload.sub)
        throw new AuthFailureError('Invalid access token');

      const keystore = await KeystoreRepo.find(
        req.user._id,
        accessTokenPayload.prm,
        refreshTokenPayload.prm,
      );

      if (!keystore) throw new AuthFailureError('Invalid access token');
      await KeystoreRepo.remove(keystore._id);

      // const accessTokenKey = crypto.randomBytes(64).toString('hex');
      // const refreshTokenKey = crypto.randomBytes(64).toString('hex');

      // await KeystoreRepo.create(req.user._id, accessTokenKey, refreshTokenKey);
      // const tokens = await createTokens(req.user, { ip: "192.168.0.2" }, accessTokenKey, refreshTokenKey);

      const { tokens } = await this.service.generate('SIGNIN', req.user as User)

      new TokenRefreshResponse('Token Issued', tokens.accessToken, tokens.refreshToken).send(res);
    }
  )

  getUsers = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {

      const users = await UserRepo.find();
      new SuccessResponse('fetch success', {
        users
      }).send(res);

    }
  )

  updateMe = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {
      const user = await UserRepo.updateInfo(req.user._id, req.body)
      new SuccessResponse('update success', { user }).send(res);
    }
  )

  businessDetails = asyncHandler(
    async (req: any, res: Response, next: NextFunction): Promise<Response | void> => {
      const { business } = await this.BusinessService.BusinessSave(req.user._id, req.body)
      new SuccessResponse('success', { business }).send(res);
    }
  )

}
