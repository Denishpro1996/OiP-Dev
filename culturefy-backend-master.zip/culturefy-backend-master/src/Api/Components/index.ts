import { Router, Request, Response, NextFunction } from 'express';
import { NotFoundError } from '../../core/ApiError';
import { AccessRoutes } from './access/access.routes';
import { CategoryRoutes } from './Category/category.routes';
import { SubCategoryRoutes } from './SubCategory/subCategory.routes';
import { QuestionRoutes } from './StrategyQuestions/question.routes';
import { AdminSettingnRoutes } from './adminSetting/adminSetting.routes';
import { SurveyRoutes } from './survey/survey.routes';
import { courseCategoryRoutes } from './courseCategory/courseCategory.routes';
import { Routes as workGoalRouter } from './WorkGoals/routes';
import { Routes as lifeRouter } from './Life/routes';
import { Routes as CulturRouter } from './Cultur/routes'
import { Routes as PostionGoalRouter } from './PostionGoal/routes'
import { Routes as BCSanswersRouter } from './BCSanswers/routes'
import { Routes as BrandAuditRouter } from './brandAudit/routes'
import { Routes as ModuleRouter } from './module/module.routes'
import { Routes as PossesCardsRouter } from './possesCards/routes'
import { Routes as CourseVideoRouter } from './courseVideos/routes'
import { Routes as CampaignRouter } from './campaign/routes'

export const registerApiRoutes = (router: Router, prefix: string = ''): void => {

  router.get(prefix, (req: Request, res: Response) => res.send('❤'));
  router.use(`${prefix}`, new AccessRoutes().router)
  router.use(`${prefix}/category`, new CategoryRoutes().router)
  router.use(`${prefix}/subcategory`, new SubCategoryRoutes().router)
  router.use(`${prefix}/questions`, new QuestionRoutes().router)
  router.use(`${prefix}/adminsetting`, new AdminSettingnRoutes().router)
  router.use(`${prefix}/survey`, new SurveyRoutes().router)
  router.use(`${prefix}/coursecategory`, new courseCategoryRoutes().router)
  router.use(`${prefix}/workgoal`, new workGoalRouter().router)
  router.use(`${prefix}/life`, new lifeRouter().router)
  router.use(`${prefix}/cultur`, new CulturRouter().router)
  router.use(`${prefix}/postiongoal`, new PostionGoalRouter().router)
  router.use(`${prefix}/bcsanswer`, new BCSanswersRouter().router)
  router.use(`${prefix}/brandaudit`, new BrandAuditRouter().router)
  router.use(`${prefix}/course`, new ModuleRouter().router)
  router.use(`${prefix}/possescards`, new PossesCardsRouter().router)
  router.use(`${prefix}/coursevideo`, new CourseVideoRouter().router)
  router.use(`${prefix}/campaign`, new CampaignRouter().router)

  router.use((req: Request, res: Response, next: NextFunction) => next(new NotFoundError()));

}
