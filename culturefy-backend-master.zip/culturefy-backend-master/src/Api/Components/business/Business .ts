import { model, Schema, Document } from 'mongoose';
import { DOCUMENT_NAME as USER_DOCUMENT_NAME } from "../../../database/model/User"
export const DOCUMENT_NAME = 'Business';
export const COLLECTION_NAME = 'businesses';

export default interface Business extends Document {
  id: Schema.Types.ObjectId,

  // 1st step
  business_name: string,
  business_describe: string,
  known_as: string,
  business_operating_start_date: string,

  // 2nd step
  business_history_describe: string,
  hr_point_person: string,
  survey_result: string,
  kickoff_session: string,

  // 3rd step
  demographic_info: string,
  historical_employee_engagement: string,
  org_chart: string,
  employe_handbook: string,
  turnover_data: string,
  exit_interview: string,

  user: Schema.Types.ObjectId,

  verified: Boolean,

}

const schema = new Schema(
  {
    // 1st step
    business_name: { type: Schema.Types.String, required: false },
    business_describe: { type: Schema.Types.String, required: false },
    known_as: { type: Schema.Types.String, required: false },
    business_operating_start_date: { type: Schema.Types.String, required: false },

    // 2nd step
    business_history_describe: { type: Schema.Types.String, required: false },
    hr_point_person: { type: Schema.Types.String, required: false },
    survey_result: { type: Schema.Types.String, required: false },
    kickoff_session: { type: Schema.Types.String, required: false },

    // 3rd step
    demographic_info: { type: Schema.Types.String, required: false },
    historical_employee_engagement: { type: Schema.Types.String, required: false },
    org_chart: { type: Schema.Types.String, required: false },
    employe_handbook: { type: Schema.Types.String, required: false },
    turnover_data: { type: Schema.Types.String, required: false },
    exit_interview: { type: Schema.Types.String, required: false },

    user: {
      type: Schema.Types.ObjectId,
      ref: USER_DOCUMENT_NAME,
      required: false,
      unique: false,
    },

    // meta
    verified: { type: Schema.Types.Boolean, default: false },
  },
  {
    versionKey: false,
    timestamps: false,
  },
);

export const BusinessModal = model<Business>(DOCUMENT_NAME, schema, COLLECTION_NAME);
