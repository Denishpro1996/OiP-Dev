import Business, { BusinessModal } from './Business ';
import { NoDataError } from '../../../core/ApiError';
import { Schema } from 'mongoose';

export default class BusinessRepo {

  public static findByUser(user: Schema.Types.ObjectId): Promise<Business> {
    return BusinessModal
      .findOne({ isDeleted: false, user })
      .select("-isDeleted -updatedAt")
      .lean<Business>()
      .exec();
  }

  public static async create(body: Business): Promise<{ business: Business }> {
    const business = await BusinessModal.create({ ...body } as Business);
    return { business };
  }

  public static async update(id: Schema.Types.ObjectId, body: Business): Promise<{ business: Business }> {
    const business = await BusinessModal.findByIdAndUpdate(id, { $set: body }, { new: true, runValidators: true });
    if (!business) throw new NoDataError();
    return { business };
  }

}
