
import User from '../../../database/model/User';
import BusinessRepo from "./business.repository";
import Business from "./Business "

export class BusinessService {

  async BusinessSave(userId: User['id'], body: Business): Promise<{ business: Business }> {
    let businessExist = await BusinessRepo.findByUser(userId)
    if (businessExist) {
      const { business } = await BusinessRepo.update(businessExist._id, body)
      return { business };
    } else {
      const { business } = await BusinessRepo.create({ ...body, user: userId } as Business)
      return { business };
    }
  }

}
