
export interface CloudinaryResponse {
    path: string,
    fileSize: number,
    fileType: string,
    fileName: string
}
